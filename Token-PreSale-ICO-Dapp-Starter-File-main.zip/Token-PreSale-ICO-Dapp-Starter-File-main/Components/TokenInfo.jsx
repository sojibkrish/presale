import React from "react";

const TokenInfo = () => {
  return <div>TokenInfo</div>;
};

export default TokenInfo;

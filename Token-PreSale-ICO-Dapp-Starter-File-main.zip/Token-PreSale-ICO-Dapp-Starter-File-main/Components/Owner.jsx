import React from "react";

const Owner = () => {
  return <div>Owner</div>;
};

export default Owner;

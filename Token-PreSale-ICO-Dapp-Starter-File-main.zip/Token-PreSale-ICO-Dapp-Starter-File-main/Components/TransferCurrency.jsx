import React from "react";

const TransferCurrency = () => {
  return <div>TransferCurrency</div>;
};

export default TransferCurrency;

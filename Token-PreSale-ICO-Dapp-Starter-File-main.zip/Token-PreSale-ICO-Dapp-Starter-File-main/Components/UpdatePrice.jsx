import React from "react";

const UpdatePrice = () => {
  return <div>UpdatePrice</div>;
};

export default UpdatePrice;

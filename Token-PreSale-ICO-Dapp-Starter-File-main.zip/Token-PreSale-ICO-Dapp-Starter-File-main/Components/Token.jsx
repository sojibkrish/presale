import React from "react";

const Token = () => {
  return <div>Token</div>;
};

export default Token;

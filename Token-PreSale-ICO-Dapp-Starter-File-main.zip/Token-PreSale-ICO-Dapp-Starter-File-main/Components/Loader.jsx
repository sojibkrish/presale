import React from "react";

const Loader = () => {
  return <div>Loader</div>;
};

export default Loader;

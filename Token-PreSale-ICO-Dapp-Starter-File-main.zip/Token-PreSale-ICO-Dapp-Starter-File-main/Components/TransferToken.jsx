import React from "react";

const TransferToken = () => {
  return <div>TransferToken</div>;
};

export default TransferToken;

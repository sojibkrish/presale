import React from "react";

const noPage = () => {
  return <div>noPage</div>;
};

export default noPage;
